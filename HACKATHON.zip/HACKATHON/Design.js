function toggleNavbar() {
    const navbarNav = document.querySelector('.navbar-nav');
    navbarNav.classList.toggle('show');
}